import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.APP_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, app: "NEXUS AI", providers: {
    gemini: Boolean(process.env.GEMINI_API_KEY),
    deepseek: Boolean(process.env.DEEPSEEK_API_KEY)
  }});
});

app.post("/api/chat", async (req, res) => {
  try {
    const { provider, message, history = [] } = req.body || {};
    if (!message || typeof message !== "string" || message.length > 12000) {
      return res.status(400).json({ error: "Envie uma mensagem válida (até 12.000 caracteres)." });
    }

    if (provider === "gemini") {
      if (!process.env.GEMINI_API_KEY) return res.status(503).json({ error: "Gemini ainda não foi configurado no servidor." });
      const contents = [];
      for (const item of history.slice(-12)) {
        if (!item || !["user", "assistant"].includes(item.role) || typeof item.text !== "string") continue;
        contents.push({ role: item.role === "assistant" ? "model" : "user", parts: [{ text: item.text.slice(0, 12000) }] });
      }
      contents.push({ role: "user", parts: [{ text: message }] });
      const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY },
        body: JSON.stringify({ contents })
      });
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ error: data?.error?.message || "Falha ao consultar Gemini." });
      const answer = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
      return res.json({ provider: "gemini", answer: answer || "Não consegui gerar uma resposta." });
    }

    if (provider === "deepseek") {
      if (!process.env.DEEPSEEK_API_KEY) return res.status(503).json({ error: "DeepSeek ainda não foi configurado no servidor." });
      const input = [];
      for (const item of history.slice(-12)) {
        if (!item || !["user", "assistant"].includes(item.role) || typeof item.text !== "string") continue;
        input.push({ role: item.role, content: item.text.slice(0, 12000) });
      }
      input.push({ role: "user", content: message });
      const r = await fetch("https://api.deepseek.com/responses", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${process.env.DEEPSEEK_API_KEY}` },
        body: JSON.stringify({ model: "deepseek-flash", input })
      });
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ error: data?.error?.message || "Falha ao consultar DeepSeek." });
      let answer = data.output_text;
      if (!answer && Array.isArray(data.output)) {
        answer = data.output.flatMap(x => x.content || []).map(x => x.text || "").join("\n");
      }
      return res.json({ provider: "deepseek", answer: answer || "Não consegui gerar uma resposta." });
    }

    return res.status(400).json({ error: "Selecione Gemini ou DeepSeek." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Erro interno no servidor. Tente novamente." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NEXUS AI server listening on ${port}`));
